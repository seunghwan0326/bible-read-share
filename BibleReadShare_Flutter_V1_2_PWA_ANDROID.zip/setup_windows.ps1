$ErrorActionPreference = "Stop"

if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
  Write-Host "Flutter가 PATH에 없습니다. 먼저 Flutter SDK를 설치하고 flutter doctor를 실행하세요." -ForegroundColor Red
  exit 1
}

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

Write-Host "[1/4] Flutter 확인"
flutter --version

if (-not (Test-Path "android") -or -not (Test-Path "ios")) {
  Write-Host "[2/4] Android/iOS 플랫폼 기본 프로젝트 생성"
  $tmp = Join-Path $root "_flutter_scaffold"
  if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }

  flutter create `
    --platforms=android,ios `
    --org com.biblereadshare `
    --project-name bible_read_share `
    $tmp

  Copy-Item (Join-Path $tmp "android") $root -Recurse -Force
  Copy-Item (Join-Path $tmp "ios") $root -Recurse -Force
  Copy-Item (Join-Path $tmp ".metadata") $root -Force
  Remove-Item $tmp -Recurse -Force
} else {
  Write-Host "[2/4] android/ios 폴더가 이미 있어 생성 생략"
}

Write-Host "[3/4] 패키지 설치"
flutter pub get

Write-Host "[4/4] 진단"
flutter doctor

Write-Host ""
Write-Host "준비 완료." -ForegroundColor Green
Write-Host "Android 테스트: flutter run"
Write-Host "iOS 최종 빌드: Mac/Xcode 또는 GitHub macOS CI 필요"
