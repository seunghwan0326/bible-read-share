import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

import '../data/bible_meta.dart';

class BibleService {
  Future<Directory> _cacheDir() async {
    final base = await getApplicationDocumentsDirectory();
    final dir = Directory('${base.path}/bible_cache');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  Future<File> _bookFile(int book) async {
    final dir = await _cacheDir();
    return File('${dir.path}/${BibleMeta.fileNames[book]}.json');
  }

  Future<String> _loadBook(int book) async {
    final file = await _bookFile(book);
    if (await file.exists()) {
      try {
        final cached = await file.readAsString();
        jsonDecode(cached);
        return cached;
      } catch (_) {}
    }

    final uri = Uri.parse('${BibleMeta.dataBase}${BibleMeta.fileNames[book]}.json');
    final response = await http.get(uri, headers: const {'User-Agent': 'BibleReadShare/Flutter'});
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('성경 본문 다운로드 실패 HTTP ${response.statusCode}');
    }
    jsonDecode(response.body);
    await file.writeAsString(response.body, flush: true);
    return response.body;
  }

  Future<String> chapterText(int book, int chapter) async {
    final raw = await _loadBook(book);
    final root = jsonDecode(raw) as Map<String, dynamic>;
    final chapters = root['chapters'] as List<dynamic>;
    final chapterObj = chapters[chapter - 1] as Map<String, dynamic>;
    final verses = chapterObj['verses'] as List<dynamic>;

    return verses.map((item) {
      final verse = item as Map<String, dynamic>;
      return '${verse['verse']}  ${verse['text']}';
    }).join('\n\n');
  }

  Future<int> cachedBookCount() async {
    var count = 0;
    for (var i = 0; i < BibleMeta.fileNames.length; i++) {
      if (await (await _bookFile(i)).exists()) count++;
    }
    return count;
  }

  Future<void> downloadAll({void Function(int done, int total)? onProgress}) async {
    for (var i = 0; i < BibleMeta.fileNames.length; i++) {
      await _loadBook(i);
      onProgress?.call(i + 1, BibleMeta.fileNames.length);
    }
  }
}
